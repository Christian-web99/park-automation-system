# Helper functions
def say_hello():
    return 'Hello from utils!'