# Main entry for PARK Automation System
print('PARK System Activated')