# EMA strategy implementation here
